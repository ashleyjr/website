1) rotational_cordic

Three data inputs: theta, x, y
Two data outputs: xprime, yprime

xprime = x.cos(theta) - y.sin(theta)
yprime = x.sin(theta) - y.cos(theta)

Control inputs: 
   reset
   clk
   start = high for good data in
Control outputs: 
   data_out_rot = high for good data out

2) vectoring_cordic

Three data inputs: x, y, z
Two data outputs: rootxy, atanba

rootxy = sqrt(x^2 + y^2)
atanba = tan^-1(y/x)

z is the starting angle of the vector hence is required compute the output but not explicitly.

Control inputs: 
   reset
   clk
   start = high for good data in
Control outputs: 
   data_out_rot = high for good data out

3) cordic_top

Make instants of both to compute the entire equation
