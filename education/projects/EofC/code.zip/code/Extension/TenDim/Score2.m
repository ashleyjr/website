function[score] = Score2(a,b)  
   dim = size(a);
   x = dim(1);
   y = dim(2);
   playDim = 1;      % Dimension to play on
   diffDimMax = 0;
   for i=1:y
      diffDim = abs(sum(a(:,i)) - sum(b(:,i)));
      if(diffDim > diffDimMax)
         diffDimMax = diffDim;
         playDim = i;
      end
   end
   score = Score(a(:,playDim),b(:,playDim));
end


