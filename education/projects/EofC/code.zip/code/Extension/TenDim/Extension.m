clear
% Evolution
lenX = 10;              % Bit string length
lenY = 10;              % Bit string length - together X x Y matrix
popSize = 25;           % Population size
mutateRate = 0.005;     % Mutation rate
genLimit = 2000;         % Run fro this many generations
lambda=0.5
%  Init Pop  %
pop1     = zeros(lenX,lenY,popSize);         % Some inits and some places holder
pop2     = zeros(lenX,lenY,popSize);
popBuf1  = zeros(lenX,lenY,popSize);
popBuf2  = zeros(lenX,lenY,popSize);
objFit1  = zeros(popSize);
objFit2  = zeros(popSize);
for gen=1:genLimit
   X = sprintf('Generation = %d', gen);   % Text output
   disp(X);
   % Pop 1
   total = 0;
   for member=1:popSize                                              % Acculumate fitness in wheel
      fitness(member) = f2(pop1(:,:,member),pop2);    
      total = total + fitness(member);
      wheel(member) = total;
   end
   sub1_y(gen) = total./(popSize^2);
   for member=1:popSize
      pick = rand(1)*total;
      i = 1;
      while(wheel(i) < pick)                                         % Spin wheel
         i = i + 1;
      end
      popBuf1(:,:,member) = pop1(:,:,i); 
      for Y=1:lenY
         popBuf1(:,Y,member) = Mutate(popBuf1(:,Y,member),(mutateRate*(lambda+((1-lambda)*sub1_y(gen)))));
      end
   end
   % Pop 2
   total = 0;
   for member=1:popSize                                              % Acculumate fitness in wheel
      fitness(member) = f2(pop2(:,:,member),pop1);    
      total = total + fitness(member);
      wheel(member) = total;
   end
   sub2_y(gen) = total./(popSize^2);
   for member=1:popSize
      pick = rand(1)*total;
      i = 1;
      while(wheel(i) < pick)                                         % Spin wheel
         i = i + 1;
      end
      popBuf2(:,:,member) = pop2(:,:,i); 
      for Y=1:lenY
         popBuf2(:,Y,member) = Mutate(popBuf2(:,Y,member),(mutateRate*(lambda+((1-lambda)*sub1_y(gen)))));
      end
   end
   % Update
   pop1 = popBuf1;
   pop2 = popBuf2;
   % Objective Fitness
   for member=1:popSize
      objFit1(member) = 0;
      objFit2(member) = 0;
      for Y=1:lenY            % Go through each dimension and find fitness of each
         objFit1(member) = objFit1(member) + ObjFit(pop1(:,Y,member));
         objFit2(member) = objFit2(member) + ObjFit(pop2(:,Y,member));
      end
   end
   % Record for graph
   avg1_y(gen) = 0;
   avg2_y(gen) = 0;
   for member=1:popSize
      pop1_x(member,gen) = gen;
      pop1_y(member,gen) = objFit1(member);
      avg1_y(gen) = avg1_y(gen) + pop1_y(member,gen);
      pop2_x(member,gen) = gen;
      pop2_y(member,gen) = objFit2(member);
      avg2_y(gen) = avg2_y(gen) + pop2_y(member,gen);
      sub1_x(gen) = gen;
      sub2_x(gen) = gen;
   end

end
% Graph 
figure(2)
grid on;
subplot(6,1,6)
scatter(sub1_x,sub1_y,25,'r','.')
xlabel('Generations')
ylabel(sprintf('Subjective\nfitness for\npopulation 1'))
grid on;
subplot(6,1,5)
scatter(sub2_x,sub2_y,25,'b','.')
set(gca,'xtick',[0:100:genLimit], 'xticklabel',{})
grid on;
ylabel(sprintf('Subjective\nfitness for\npopulation 2'))
subplot(6,1,[1 4]) 
for pop=1:popSize
   scatter(pop1_x(pop,:),pop1_y(pop,:),25,'g','.')
   hold on
   scatter(pop2_x(pop,:),pop2_y(pop,:),25,'m','.')
   hold on
end
avg1_y = avg1_y./popSize
scatter(pop1_x(pop,:),avg1_y,100,'r','.')
avg2_y = avg2_y./popSize
scatter(pop2_x(pop,:),avg2_y,100,'b','.')
ylim([0 100])
ylabel(sprintf('Objective\nfitness\nfor both populations'))
set(gca,'xtick',[0:100:genLimit], 'xticklabel',{})
grid on;


