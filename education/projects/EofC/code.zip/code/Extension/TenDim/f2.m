function[fitness] = f2(a,S)
   fitness = 0;
   tests = size(S);
   for test=1:tests(3)
      fitness = fitness + Score2(a,S(:,:,test));
   end
end


