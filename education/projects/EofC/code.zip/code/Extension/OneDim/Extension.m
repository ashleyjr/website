clear
% Evolution
lenString = 100;        % Bit string length
popSize = 25;           % Population size
mutateRate = 0.005;     % Mutation rate
genLimit = 6000;         % Run fro this many generations
lambda=0.1
%  Init Pop  %
   pop1     = zeros(lenString,popSize);         % Some inits and some places holder
   pop2     = zeros(lenString,popSize);
   popBuf1  = zeros(lenString,popSize);
   popBuf2  = zeros(lenString,popSize);
   for gen=1:genLimit
      %  EA Stuff  %
      total = 0;
      for member=1:popSize                                              % Acculumate fitness in wheel
         fitness(member) = f(pop1(:,member),pop2(:,randi(popSize)));                    % Every member against sample TODO: random(er) sample?
         total = total + fitness(member);
         wheel(member) = total;
      end
      sub1_y(gen) = total./(popSize);
      for member=1:popSize
         pick = rand(1)*total;
         i = 1;
         while(wheel(i) < pick)                                         % Spin wheel
            i = i + 1;
         end
         popBuf1(:,member) = pop1(:,i);                                 % Update and mutate 
         popBuf1(:,member) = Mutate(popBuf1(:,member),(mutateRate*(lambda+((1-lambda)*sub1_y(gen)))));
      end
      total = 0;                                                        % Repeat above but for second population
      for member=1:popSize
         fitness(member) = f(pop2(:,member),pop1(:,randi(popSize)));
         total = total + fitness(member);
         wheel(member) = total;
      end
      sub2_y(gen) = total./(popSize);
      for member=1:popSize
         pick = rand(1)*total;
         i = 1;
         while(wheel(i) < pick)
            i = i + 1;
         end
         popBuf2(:,member) = pop2(:,i); 
         popBuf2(:,member) = Mutate(popBuf2(:,member),(mutateRate*(lambda+((1-lambda)*sub2_y(gen)))));
      end
      pop1 = popBuf1;   % Population update
      pop2 = popBuf2;   % Population update
      % Record for graph %
      X = sprintf('Generation = %d', gen);   % Text output
      disp(X)
      avg1_y(gen) = 0;
      avg2_y(gen) = 0;
      for pop=1:popSize
         pop1_x(pop,gen) = gen;
         pop1_y(pop,gen) = ObjFit(pop1(:,pop));
         avg1_y(gen) = avg1_y(gen) + pop1_y(pop,gen);
         pop2_x(pop,gen) = gen;
         pop2_y(pop,gen) = ObjFit(pop2(:,pop));
         avg2_y(gen) = avg2_y(gen) + pop2_y(pop,gen);
         sub1_x(gen) = gen;
         sub2_x(gen) = gen;
      end
   
   end
   % Graph 
figure(1)
ylabel(sprintf('Objective fitness'))
xlabel(sprintf('Generations'))
title(sprintf('Lambda = %1.1f',lambda))

grid on;
subplot(6,1,6)
scatter(sub1_x,sub1_y,25,'r','.')
ylim([0 1])
ylabel(sprintf('Subjective\nfitness for\npopulation 1'))
xlabel(sprintf('Generations'))
grid on;
subplot(6,1,5)
scatter(sub2_x,sub2_y,25,'b','.')
ylim([0 1])
set(gca,'xtick',[0:100:genLimit], 'xticklabel',{})
grid on;
ylabel(sprintf('Subjective\nfitness for\npopulation 2'))
subplot(6,1,[1 4]) 
for pop=1:popSize
   scatter(pop1_x(pop,:),pop1_y(pop,:),25,'g','.')
   hold on
   scatter(pop2_x(pop,:),pop2_y(pop,:),25,'m','.')
   hold on
end
avg1_y = avg1_y./popSize
scatter(pop1_x(pop,:),avg1_y,100,'r','.')
avg2_y = avg2_y./popSize
scatter(pop2_x(pop,:),avg2_y,100,'b','.')
ylim([0 100])
ylabel(sprintf('Objective\nfitness\nfor both populations'))
set(gca,'xtick',[0:100:genLimit], 'xticklabel',{})
grid on;
ylabel(sprintf('Objective fitness'))
title(sprintf('Lambda = %1.1f',lambda))





