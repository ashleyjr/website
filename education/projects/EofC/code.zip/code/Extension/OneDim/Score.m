function[score] = Score(a,b)   
   if(ObjFit(a) > ObjFit(b))                  % Scoring from paper
      score = 1; 
   else        
      score = 0;
   end
end


