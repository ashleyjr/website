function[fitness] = f(a,S)
   fitness = 0;
   tests = size(S);
   for test=1:tests(2)
      fitness = fitness + Score(a,S(:,test));
   end
end


