function[mutant] = Mutate(normal,rate) % Any length bit string
   mutant = normal;                    % Init output as input
   for i=1:size(normal)                % Access each bit
      if(rand(1) < rate)               % Supplies mutation rate
         if(mutant(i) == 0)            % Flip bits
            mutant(i) = 1;
         else
            mutant(i) = 0;
         end
      end
   end
end
