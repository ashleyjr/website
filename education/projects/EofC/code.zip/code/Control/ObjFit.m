function[fitness] = ObjFit(bitString)
   fitness = sum(bitString);           % Just sim the vectors
end


