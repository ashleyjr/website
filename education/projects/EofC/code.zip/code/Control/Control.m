clear
% Evolution
lenString = 100;        % Bit string length
popSize = 25;           % Population size
mutateRate = 0.005;     % Mutation rate
genLimit = 600;         % Run fro this many generations
%  Init Pop  %
pop1 = zeros(lenString,popSize);
pop2 = ones(lenString,popSize);
for gen=1:genLimit
   for member=1:popSize                      
      pop1(:,member) = Mutate(pop1(:,member),mutateRate);  
      pop2(:,member) = Mutate(pop2(:,member),mutateRate);   
   end
   X = sprintf('Generation = %d', gen);   % Text output
   disp(X)
   for pop=1:popSize
      pop1_x(pop,gen) = gen;
      pop1_y(pop,gen) = ObjFit(pop1(:,pop));
      pop2_x(pop,gen) = gen;
      pop2_y(pop,gen) = ObjFit(pop2(:,pop));
   end
end
for pop=1:popSize
   scatter(pop1_x(pop,:),pop1_y(pop,:),100,'r','.')
   hold on
   scatter(pop2_x(pop,:),pop2_y(pop,:),100,'b','.')
   hold on
end


