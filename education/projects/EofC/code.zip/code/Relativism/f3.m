function[fitness] = f3(a,S)
   fitness = 0;
   tests = size(S);
   for test=1:tests(3)
      fitness = fitness + Score3(a,S(:,:,test));
   end
end


