function[fitness] = ObjFit(bitString)
   fitness = sum(bitString);           % Just sum the vectors
end


