%Ashley Robinson
%10/11/12
%----------------------COMP3032-Contour_test.m
%

clear %Clean up last run

%-------------------------------------------------------TIP_CODE
% Read in a png file into a Matlab matrix
im = imread ('Data/pint.png')
size(im)
% Convert the image to have values in the range 0 - 1
im = double (im );
imax = max ( max (im ));
imin = min ( min (im ));
im = (im - imin )/( imax - imin );
%-------------------------------------------------------/TIP_CODE


%-------------------------------------------------------Make_contours
[Y,X] = size(im)

points = 200
center = [round(X/2),round(Y/2)];
if(X>Y)
   radius = center(2) - 1;
else
   radius = center(1) - 1;
end
%Lazy but for code re use
v_1 = Circle_contour(center,round(radius/10),points)
v_2 = Circle_contour(center,radius,points)

size(v_1)
size(v_2)

v_3 = Opposite_Circle_contour(center,round(radius/10),points)
v_4 = Opposite_Circle_contour(center,radius,points)

%Plot the image with search space contours
figure(1)
   subplot(2,2,1)
   imagesc(im)
   axis([1 X 1 Y]);
   axis square
   title('Image with boundary contours')
   colormap(gray)
   hold on
   plot (v_3(: ,1) ,v_3(: ,2) , 'r+-','LineWidth' ,2)
   plot (v_4(: ,1) ,v_4(: ,2) , 'r+-','LineWidth' ,2)

%-------------------------------------------------------/Make_contours


%-------------------------------------------------------Parameters
lambda = 0.7
M = 80
%Tell user
%-------------------------------------------------------/Parameters



%-------------------------------------------------------find a contour

%pass the search space matrix to the contour finder
%Also considers h[M,N] = size(space);ow points are mapped
[space,mapping] = Search_Space(v_1,v_2,M,im);
[M,N] = size(space);

%Optimal contour
[contour,energy] = Contour(space,lambda);

%Plot search space and contour
   subplot(2,2,3)
   imagesc(space)
   axis([1 N 1 M]);
   axis square
   title('Intial contour')
   colormap(gray)

   hold on
   plot(contour(:,1),contour(:,2),'r+-','LineWidth',2)

%Use a point on the opposite side of this contour to make a better one
contour(round(points/2),2)
[space,mapping] = Search_Space(v_3,v_4,M,im);
[contour,energy] = Init_Contour(space,lambda,contour(round(points/2),2));


%Plot new search space
   subplot(2,2,4)
   imagesc(space)
   axis([1 N 1 M]);
   axis square
   temp = sprintf('Lambda = %0.5g',(lambda))
   title('Optimised contour')
   colormap(gray)

   hold on
   plot(contour(:,1),contour(:,2),'r+-','LineWidth',2)

%Make the ends meet
contour(1,:) = contour(length(contour),:)

%Map the contour back to the original image
Image_line = Map2image(im,mapping,contour);

%Plot image and contour
   subplot(2,2,2)
   [M,N] = size(im);
   imagesc(im)
   axis([1 N 1 M]);
   title('The final contour')
   axis square
   colormap(gray)

   hold on
   plot(Image_line(:,1),Image_line(:,2),'r.-','LineWidth',2)

   figure(2)
   [M,N] = size(im);
   imagesc(im)
   axis([1 N 1 M]);
   title('The final contour')
   axis square
   colormap(gray)

   hold on
   plot(Image_line(:,1),Image_line(:,2),'r.-','LineWidth',2)

%-------------------------------------------------------/find a contour


