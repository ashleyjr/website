%Ashley Robinson
%10/11/12
%----------------------COMP3032-Contour.m
%

%Takes the image matrix and lambda
%calls the energy function
%return the best contour, the energy slope and the energy mountain range
function [contour,energy] = Contour(im_matrix,lambda)

   N = length(im_matrix(1,:));
   M = length(im_matrix(:,1));

   %{ 
   %For basic energy
   
   for j=1:1:M

      energy(j,1) =  Energy(lambda,j,j,j,M,im_matrix(j,1));  %Make the angle zero

   end

   for i=2:1:N
      for j=1:1:M
         position(j,i,1) = 1;
         position(j,i,2) = 1;
         energy(j,i)= energy(1,i-1) + Energy(lambda,1,j,1,M,im_matrix(j,i));%It could be right first time?
         for v0=1:1:N
            for v2=1:1:N
            check = energy(v0,i-1) + Energy(lambda,v0,j,v2,M,im_matrix(j,i));
            lowest = energy(position(j,i,1),i-1) + Energy(lambda,position(j,i,1),j,position(j,i,2),M,im_matrix(j,i));
               if(check < lowest)
                  energy(j,i) = check;
                  position(j,i,1) = v0;%Where you have been
                  position(j,i,2) = v2;%Where you should go
               end
            end
         end
      end
   end
   %}



   %For better energy  
   for j=1:1:M

      energy(j,1) =  Energy(lambda,j,j,j,M,im_matrix(j,1));  %Make the angle zero

   end

   for i=2:1:N
      for j=1:1:M
         energy(j,i)= energy(1,i-1) + Energy(lambda,1,j,1,M,im_matrix(j,i));%It could be right first time?
         for v0=1:1:M
            for v2=1:1:M
            check = energy(v0,i-1) + Energy(lambda,v0,j,v2,M,im_matrix(j,i));
               if(check < energy(j,i))
                  energy(j,i) = check;
                  position(j,i) = v0;%Where you have been
               end
            end
         end
      end
   end

   %Start on the lowest energy
   next = 1;
   for pos=1:M
      if(energy(pos,N) < energy(next,N))
         next = pos;
      end
   end


   %Backtrack the position matrix
   for pos=N:-1:1
      contour(pos,1) = pos;
      contour(pos,2) = next;
      last = next;
      next = position(next,pos);
   end

end

