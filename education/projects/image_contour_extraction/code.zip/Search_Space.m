%Ashley Robinson
%9/11/12
%----------------------COMP3032-Search_Space.m
%

%Takes two contours and an image and returns the search space image
function [Intensity_matrix, mapping] = Search_Space(contour_1,contour_2,M,im)
   
   %Are the contours of equal length?
   if(length(contour_1) == length(contour_2))
      N = length(contour_1)

      %Nested loops to populate the matrix
      for i =1:N
         %Optional sanity checking
         %{
         fprintf('#%i :\n',i)
         fprintf('Contour 1: %i %i \n',contour_1(i,1),contour_1(i,2))
         fprintf('Contour 2: %i %i\n',contour_2(i,1),contour_2(i,2))
         %}

         %Difference between axis coordinates
         xdiff = contour_2(i,1) - contour_1(i,1);
         ydiff = contour_2(i,2) - contour_1(i,2);

         %Optional sanity checking
         %{
         fprintf('Y-axis difference: %i \n',ydiff)
         fprintf('X-axis difference: %i \n',xdiff)
         %}

         %step thorugh so it fits in matrix
         ystep = ydiff/M;
         xstep = xdiff/M;

         %Optional sanity checking
         %{
         fprintf('Ystep: %i \n',ystep)
         fprintf('Xstep: %i \n\n',xstep)
         %}

         %Use trig to populate the intensity matrix

         %First and last set of coordinates are already known
         Intensity_matrix(1,i) = im(contour_1(i,2),contour_1(i,1));
         Intensity_matrix(M,i) = im(contour_2(i,2),contour_2(i,1));

         mapping(1,i,1) = contour_1(i,1);
         mapping(1,i,2) = contour_1(i,2);

         mapping(M,i,1) = contour_2(i,1);
         mapping(M,i,2) = contour_2(i,2);


         %Limits don't fill row 1 and M
         for j = 2:(M-1)
            %Optional sanity checking
            %{
            fprintf('Y added: %i   ',y_coordinate)
            fprintf('X added: %i \n',x_coordinate)
            %}

            %Round to nearest integer to satisfy indexing
            x_coordinate = round(contour_1(i,1) + (xstep*j));
            y_coordinate = round(contour_1(i,2) + (ystep*j));

            Intensity_matrix(j,i) = im(y_coordinate,x_coordinate);

            %This is so we can take the contour back to original image
            mapping(j,i,1) = x_coordinate;
            mapping(j,i,2) = y_coordinate;
         end
      end     
   else
      fprintf('ERROR: The two contours are not of the same length')%Error message
   end

end

