function[energy] = Energy_naive(lambda,v0,v1,v2,M,intensity)
   %looking for white so 1 - intensity
   %(lambda*(((abs(v2 - 2*v1 + v0))^2)/(abs((v2 - v0)^2))))
   %((1 - lambda)*(1 - intensity))

   v0_1 = 1 + (abs(v1 - v0)^2);
   v1_2 = 1 + (abs(v2 - v1)^2);
   v0_2 = 4 + (abs(v2 - v0)^2);
   energy = (lambda*() + ((1 - lambda)*(1 - intensity));%BASIC
end
