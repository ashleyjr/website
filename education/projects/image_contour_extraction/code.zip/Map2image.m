%Ashley Robinson
%9/11/12
%----------------------COMP3032-Search_Space.m
%

function [line] = Map2image(im,mapping,contour)
    
   i = 1;
   for i = 1:1:length(contour())
      line(i,1) = mapping(contour(i,2),contour(i,1),1);
      line(i,2) = mapping(contour(i,2),contour(i,1),2);
   end
end
