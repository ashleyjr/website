%Ashley Robinson
%10/11/12
%----------------------COMP3032-Contour.m
%

%Takes the image matrix and lambda
%calls the energy function
%return the best contour, the energy slope and the energy mountain range
%Optimised!!
function [contour,energy,mountains] = Eff_Contour(im_matrix,lambda,jump)

   N = length(im_matrix(1,:));
   M = length(im_matrix(:,1));

   %Find the best start
   for i=1:1:M
      energy(i,1) =  Energy(lambda,i,i,i,M,im_matrix(i,1));  
   end
   %Break in to three sections to stop out of index issues and no need for switch statment
   for i=2:1:N %Move along the contour
      %LOW
      for j=1:1:jump %Move between the contours, up until jump      
         energy(j,i) = energy(1,i-1) + Energy(lambda,1,j,1,M,im_matrix(j,i)); %It could be right first time?
         for v0=1:1:(j + jump)  %Last
            for v2=1:1:(j + jump)  %Possible
            check = energy(v0,i-1) + Energy(lambda,v0,j,v2,M,im_matrix(j,i));
               if(check < energy(j,i))
                  energy(j,i) = check;
                  position(j,i) = v0;
               end
            end
         end
      end
      %MID
      for j=(jump + 1):1:(M - jump) %Move between the contours, bound by jump      
         energy(j,i) = energy(1,i-1) + Energy(lambda,1,j,1,M,im_matrix(j,i)); %It could be right first time?
         for v0=(j - jump):1:(j + jump)  %Last
            for v2=(j - jump):1:(j + jump)  %Possible
            check = energy(v0,i-1) + Energy(lambda,v0,j,v2,M,im_matrix(j,i));
               if(check < energy(j,i))
                  energy(j,i) = check;
                  position(j,i) = v0;
               end
            end
         end
      end
      %HIGH
      for j=(M - jump + 1):1:M%Move between the contours, jump below M  
         energy(j,i) = energy(1,i-1) + Energy(lambda,1,j,1,M,im_matrix(j,i)); %It could be right first time?
         for v0=(j - jump):1:M  %Last
            for v2=(j - jump):1:M  %Possible
            check = energy(v0,i-1) + Energy(lambda,v0,j,v2,M,im_matrix(j,i));
               if(check < energy(j,i))
                  energy(j,i) = check;
                  position(j,i) = v0;
               end
            end
         end
      end
   end
   %Start backtrtacking on the lowest energy
   next = 1;
   for pos=1:M
      if(energy(pos,N) < energy(next,N))
         next = pos;
      end
   end
   %Backtrack the position matrix
   for pos=N:-1:1
      contour(pos,1) = pos;
      contour(pos,2) = next;
      last = next;
      next = position(next,pos);
   end

end

