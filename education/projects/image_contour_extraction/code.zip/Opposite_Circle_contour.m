
function [contour] = Opposite_Circle_contour(center,radius,points) 

   step = (2*pi)/points;
   count = 1;
   for i=pi:step:(3*pi)
      %Euler's ident
      contour(count,:) = [round(center(1) + (radius*sin(i))),round(center(2) + (radius*cos(i)))];
      count = count + 1;
   end
   
end
   
