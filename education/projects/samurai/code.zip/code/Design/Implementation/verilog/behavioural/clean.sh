rm -rf waves.shm/
rm -rf .simvision/
rm ncverilog.log 
rm ncverilog.key 
rm -rf INCA_libs/
