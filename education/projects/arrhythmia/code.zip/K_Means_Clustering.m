%Ashley Robinson
%10/04/12
%COMP3008
%K_Means_Clustering.m
clear
% K >= 2
K = 2;
%Load the data
data = LoadData('arrhythmia.data');%Load the data from text file
data = Normalise(data);
instances = size(data,2);%These are handy to know
attributes = size(data,1);
%populate all means
count = 0;
while(min(count) == 0)
   %initialise
   assigned_cluster = randi([1,K],1,instances);
   [old_cluster_mean] = Calculate_Means(assigned_cluster,K,data);
   assigned_cluster = Assign_New_Cluster(old_cluster_mean,K,data);%Assign data to random cluster means
   [cluster_mean] = Calculate_Means(assigned_cluster,K,data);
   %Converge
   i = 0;
   while(sum(abs(sum(old_cluster_mean - cluster_mean)  ~= zeros(1,K))))%Test for same means
      old_cluster_mean = cluster_mean;
      assigned_cluster = Assign_New_Cluster(cluster_mean,K,data);
      [cluster_mean] = Calculate_Means(assigned_cluster,K,data);
      i = i + 1;
      Output(i,K,instances,assigned_cluster);%User output
   end
   count = Cluster_Count(K,instances,assigned_cluster);%How many data points to each cluster?
end
