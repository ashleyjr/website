%Ashley Robinson
%10/04/12
%COMP3008
%Calculate_Means.m
function[cluster_mean] = Calculate_Means(assigned_cluster,K,data)   
   instances = size(data,2);
   attributes = size(data,1);
   for i=1:K
      cluster_mean(:,i) = zeros(attributes,1);
      count = 0;
      for j=1:instances
         if(assigned_cluster(j) == i)
            count = count + 1;%Keep track of the number of instances in the cluster
            cluster_mean(:,i) = cluster_mean(:,i) + data(:,j);%Total all the vectors 
         end
      end
      if(count ~= 0)
         cluster_mean(:,i) = cluster_mean(:,i)./count;%calculate mean
      end
   end
end
