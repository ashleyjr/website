%Ashley Robinson
%10/04/12
%COMP3008
%Cluster_Count.m
function[count] = Cluster_Count(K,instances,assigned_cluster)   
   count = zeros(K,1);
   for i=1:instances
      for j=1:K
         if(assigned_cluster(i) == j)
            count(j) = count(j) + 1;
         end
      end
   end
end
