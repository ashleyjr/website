%Ashley Robinson
%10/04/12
%COMP3008
%LoadData.m
function[data] = LoadData(Path_to_data)
   %Open data file in same directory
   arrhythmia_data = fopen(Path_to_data);
   %global init
   instance = 0;
   while ~feof(arrhythmia_data)%While not at the end of the file
      instance = instance + 1;
      line = fgetl(arrhythmia_data);%Read a line from the file
      start = 1;
      %disp(line)%Just to see some output
      attribute = 0;
      for j=1:length(line)
         %Look for CSVs
         if (line(j) == ',')
            attribute = attribute + 1;
            if (line(start:(j - 1)) == '?')
               miss_mask(attribute,instance) = 1;%take a note of missing
               data(attribute,instance) = 0;
            else
               miss_mask(attribute,instance) = 0;%need to keep dimensions up
               data(attribute,instance) = str2num(line(start:(j - 1)));
            end
            start = j + 1;%One in front of the comma
         end
      end
   end
   fclose(arrhythmia_data);
   %Replace unkown data with the mean of that attribute
   for i=1:attribute
      total = 0;
      count = 0;
      for j=1:instance
         if(miss_mask(i,j) == 0)
            total = total + data(i,j);
            count = count + 1;
         end
      end
      total = total./count;%The mean of this attribute
      miss_mask(i,:) = miss_mask(i,:).*total;
   end
   data = data + miss_mask;%Missing values are zero so add miss mask
   %Remove attribute 14
   att_point = 1;
   for i=1:attribute
      if(i ~= 14)
         for j=1:instance
            temp(att_point,j) = data(i,j);
         end
         att_point = att_point + 1;
      end
   end
   data = temp;
   %All info now in matrix
   info =  sprintf('Instances: %d \nAttributes: %d ',size(data,2), size(data,1));
   disp(info)
end
