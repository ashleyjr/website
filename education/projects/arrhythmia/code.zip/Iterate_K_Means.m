%Ashley Robinson
%10/04/12
%COMP3008
%Iterate_K_Means.m
clear
%Binary fixed
K = 2;
iterations = 250;

%Load the data
data = LoadData('arrhythmia.data');%Load the data from text file
data = Normalise(data);
instances = size(data,2);%These are handy to know
attributes = size(data,1);


for iter=1:iterations
    info = sprintf('Iteration: %d',iter)
    disp(info)
   %populate all means
   count = 0;
   while(min(count) == 0)
      %initialise
      assigned_cluster = randi([1,K],1,instances);
      [old_cluster_mean] = Calculate_Means(assigned_cluster,K,data);
      assigned_cluster = Assign_New_Cluster(old_cluster_mean,K,data);%Assign data to random cluster means
      [cluster_mean] = Calculate_Means(assigned_cluster,K,data);
      %Converge
      i = 0;
      while(sum(abs(sum(old_cluster_mean - cluster_mean)  ~= zeros(1,K))))%Test for same means
         old_cluster_mean = cluster_mean;
         assigned_cluster = Assign_New_Cluster(cluster_mean,K,data);
         [cluster_mean] = Calculate_Means(assigned_cluster,K,data);
         i = i + 1;
         %Output(i,K,instances,assigned_cluster);%User output
      end
      count = Cluster_Count(K,instances,assigned_cluster)%How many data points to each cluster?
      if(abs(count(1) - count(2)) < 20)
          count = 0;
          disp('close')
      end
   end
   cluster(:,:,iter) = cluster_mean; 
end

%First mean holds good patients
assigned_cluster = Assign_New_Cluster(cluster(:,:,1),K,data);
count = Cluster_Count(K,instances,assigned_cluster);
if(count(1) > count(2))
   mean_cluster(:,1) = cluster(:,1,1);
   mean_cluster(:,2) = cluster(:,2,1);
else
   mean_cluster(:,2) = cluster(:,1,1);
   mean_cluster(:,1) = cluster(:,2,1);
end

for iter=2:iterations
   assigned_cluster = Assign_New_Cluster(cluster(:,:,iter),K,data);
   count = Cluster_Count(K,instances,assigned_cluster);

   if(count(1) > count(2))
      mean_cluster(:,1) = mean_cluster(:,1) + cluster(:,1,iter);
      mean_cluster(:,2) = mean_cluster(:,2) + cluster(:,2,iter);
   else
      mean_cluster(:,2) = mean_cluster(:,2) + cluster(:,1,iter); 
      mean_cluster(:,1) = mean_cluster(:,1) + cluster(:,2,iter);
   end
end
mean_cluster = mean_cluster./iterations
assigned_cluster = Assign_New_Cluster(mean_cluster,K,data);
count = Cluster_Count(K,instances,assigned_cluster)

for iter=1:iterations
   assigned_cluster = Assign_New_Cluster(cluster(:,:,iter),K,data);
   count = Cluster_Count(K,instances,assigned_cluster);
   if(count(1) > count(2))
      variance(iter,1) = Calculate_Distance(mean_cluster(:,1),cluster(:,1,iter));
      variance(iter,2) = Calculate_Distance(mean_cluster(:,2),cluster(:,2,iter));
   else
      variance(iter,2) = Calculate_Distance(mean_cluster(:,2),cluster(:,1,iter));
      variance(iter,1) = Calculate_Distance(mean_cluster(:,1),cluster(:,2,iter));
   end
end
figure(1)
hist(variance(:,1),100)
xlabel('Variance')
ylabel('Frequency')
title('Cluster 1')
figure(2)
hist(variance(:,2),100)
title('Cluster 2')
xlabel('Variance')
ylabel('Frequency')
variance


kick1 =input('kick 1 (0 to quit):')
kick2 =input('kick 2:')
while(sum(kick1) ~= 0)
%-------------variance fix
j = 0;
for iter=1:iterations
   if(sum(variance(iter,1) > kick1) | sum(variance(iter,2) > kick2))
       disp('out')
   else
       j = j + 1;
       new_cluster(:,:,j) = cluster(:,:,iter);
   end
end

%First mean holds good patients
assigned_cluster = Assign_New_Cluster(new_cluster(:,:,1),K,data);
count = Cluster_Count(K,instances,assigned_cluster);
if(count(1) > count(2))
   mean_cluster(:,1) = new_cluster(:,1,1);
   mean_cluster(:,2) = new_cluster(:,2,1);
else
   mean_cluster(:,2) = new_cluster(:,1,1);
   mean_cluster(:,1) = new_cluster(:,2,1);
end

for iter=2:j
   assigned_cluster = Assign_New_Cluster(new_cluster(:,:,iter),K,data);
   count = Cluster_Count(K,instances,assigned_cluster);

   if(count(1) > count(2))
      mean_cluster(:,1) = mean_cluster(:,1) + new_cluster(:,1,iter);
      mean_cluster(:,2) = mean_cluster(:,2) + new_cluster(:,2,iter);
   else
      mean_cluster(:,2) = mean_cluster(:,2) + new_cluster(:,1,iter); 
      mean_cluster(:,1) = mean_cluster(:,1) + new_cluster(:,2,iter);
   end
end
mean_cluster = mean_cluster./j
assigned_cluster = Assign_New_Cluster(mean_cluster,K,data);
count = Cluster_Count(K,instances,assigned_cluster)

for iter=1:j
   assigned_cluster = Assign_New_Cluster(new_cluster(:,:,iter),K,data);
   count = Cluster_Count(K,instances,assigned_cluster);
   if(count(1) > count(2))
      new_variance(iter,1) = Calculate_Distance(mean_cluster(:,1),new_cluster(:,1,iter));
      new_variance(iter,2) = Calculate_Distance(mean_cluster(:,2),new_cluster(:,2,iter));
   else
      new_variance(iter,2) = Calculate_Distance(mean_cluster(:,2),new_cluster(:,1,iter));
      new_variance(iter,1) = Calculate_Distance(mean_cluster(:,1),new_cluster(:,2,iter));
   end
end
figure(3)
hist(new_variance(:,1),100)
xlabel('Variance')
ylabel('Frequency')
title('Cluster 1')
figure(4)
hist(new_variance(:,2),100)
title('Cluster 2')
xlabel('Variance')
ylabel('Frequency')
new_variance
kick1 =input('kick 1 (0 to quit):')
kick2 =input('kick 2:')
end

