%Ashley Robinson
%10/04/12
%COMP3008
%Assign_New_Cluster.m
function[assigned_cluster] = Assign_New_Cluster(cluster_mean,K,data) 
   for i=1:size(data,2)%instances
      assigned_cluster(i) = 1;%init
      dist = Calculate_Distance(cluster_mean(:,1),data(:,i));
      for j=2:K
         test = Calculate_Distance(cluster_mean(:,j),data(:,i)); 
         if(test < dist)
            assigned_cluster(i) = j;
            dist = test;
         end
      end
   end
end
