%Ashley Robinson
%10/04/12
%COMP3008
%Output.m
function[] = Output(iter,K,instances,assigned_cluster)   
   count = Cluster_Count(K,instances,assigned_cluster);%How many data points to each cluster
   disp(sprintf('Iteration: %d',iter));
   for i=1:K
      disp(sprintf('              Cluster %d size: %d ',i,count(i)))
   end 
end
