%Ashley Robinson
%21/04/12
%COMP3008
%Normalise.m
function[new_data] = Normalise(data)
   instances = size(data,2);%These are handy to know
   attributes = size(data,1);
   for i=1:attributes
      mu = data(i,1);
      for j=2:instances
         mu = mu + data(i,j);
      end
      mu = mu./instances;
      sigma = (data(i,1) - mu)^2;
      for j=2:instances
         sigma = sigma + (data(i,j) - mu)^2;
      end
      sigma = sqrt(sigma./(instances - 1));
      for j=1:instances
         if(sigma == 0)
            new_data(i,j) = 0;
         else
            new_data(i,j) = (data(i,j) - mu)./sigma;
      end
   end
end
