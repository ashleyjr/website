%Ashley Robinson
%10/04/12
%COMP3008
%Calculate_Distance.m
function[distance] = Calculate_Distance(vector_1,vector_2)   
   distance = 0;
   for i=1:size(vector_1)
       distance = distance + ((vector_1(i) - vector_2(i))^2);%Accumulate
   end
   distance = sqrt(distance);%Euclidean
end
